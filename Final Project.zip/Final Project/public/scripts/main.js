


const AUTH_TOKEN       = "db37b700-10d8-4b2a-b86a-53c6a38175f9";
const COLLECTION       = "Pic";													// Firestore Collection ID
const KEY_IMAGE        = "imageUrl";											// Firestore Document Key for Image Url
const KEY_CAPTION      = "caption";		
const KEY_NOTES = "notes";										// Firestore Document Key for Caption
const KEY_AUTHOR       = "Author";
const KEY_LAST_UPDATED = "lastTouched";
const KEY_LIKED = "liked";


// got func from prof
function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}


// Image Class
class ImageItem {
    constructor(id, imageUrl, caption, author, notes, liked) {
        this.id = id;
        this.imageUrl = imageUrl;
        this.caption = caption;
        this.notes = notes;
        this.author = author;
        this.liked = liked || false; // Initialize likedBy as an empty array
    }
}


class ListPageManager {

	// Constructor
	constructor( uid ) {
		this.docs   = [];
		this.socket = null;
		this.fsdb   = firebase.firestore().collection( COLLECTION );
		this.uid    = uid;
	}

	// Open Database Connection
	openDatabase( changeListener ) {
		let query = this.fsdb.orderBy( KEY_LAST_UPDATED, "desc" ).limit( 50 );
		if ( this.uid ) query = query.where( KEY_AUTHOR, "==", this.uid );
		this.socket = query.onSnapshot((querySnapshot) => {
				this.docs = querySnapshot.docs;
				if ( changeListener ) changeListener();
			});
	}

	// Close Database Connection
	closeDatabase() {
		this.socket();
	}

	// Add Image
	add( imgURL, caption, notes ) {
		this.fsdb.add({
				[ KEY_IMAGE ]: imgURL,
				[ KEY_CAPTION ]: caption,
				[KEY_NOTES]: notes,
				[ KEY_AUTHOR ]: iface.loginManager.uid,
				[ KEY_LIKED ]: false,
				[ KEY_LAST_UPDATED ]: firebase.firestore.Timestamp.now()
			}).then( addedDoc => {
				console.log( "Doc Added: " + addedDoc.id );
			}).catch( error => {
				console.log( error );
			});
	}

	// get doc length
	get length() {
		return this.docs.length;
	}

	// get image by index
	getImageByIndex( index ) {
		let doc = this.docs[index];
		const notes = doc.get(KEY_NOTES);
		console.log("Notes:", notes); // Add this line
		return new ImageItem(
		  doc.id,
		  doc.get(KEY_IMAGE),
		  doc.get(KEY_CAPTION),
		  notes,
		  doc.get(KEY_AUTHOR),
		  doc.get(KEY_LIKED)
			);
	}

}


class ListPageController {

	// custuctor
	constructor() {
		iface.ListPageManager.openDatabase( this.update );

		$( "#addPhotoDialog" ).on( "show.bs.modal", () => {
			document.querySelector( "#addPhotoDialog #inputImage" ).value = "";
			document.querySelector( "#addPhotoDialog #inputCaption" ).value = "";
			
		});

		$( "#addPhotoDialog" ).on("shown.bs.modal", () => {
			document.querySelector( "#inputImage" ).focus();
		});

		document.querySelector( "#sumbitAddPhoto" )
			.addEventListener( "click", () => {
				iface.ListPageManager.add(
						document.querySelector( "#inputImage" ).value,
						document.querySelector( "#inputCaption" ).value,
						document.querySelector("#inputNotes").value
					);
		});
	}


	// update
	update() {
		const list = document.querySelector( "#imageListContainer" );
		list.innerHTML = "";

		for ( let i = 0; i < iface.ListPageManager.length; i++ ) {
			const image   = iface.ListPageManager.getImageByIndex( i );
			const newCard = ListPageController._createCard( image );
			newCard.addEventListener( "click", () => {
				window.location.href = `/image.html?id=${ image.id }`;
			});
			list.appendChild( newCard );
		}
	}

	// create card
	static _createCard( image ) {
			return htmlToElement(
				`<div class="pin">
  <button class="btn btn-secondary" type="button" id="${image.id}-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <p class="caption">${image.caption}</p>
  
      ${
        image.author == iface.loginManager.uid
          ? `<p>Posted by me</p>`
          : ''
      }
</div>`
	)};

}


class DetailPageManager {

	// custructor
	constructor( imageID ) {
		this.id     = imageID;
		this.doc    = {};
		this.socket = null;
		this.fsdb   = firebase.firestore().collection( COLLECTION ).doc( imageID );
	}

	// open database
	openDatabase( changeListener ) {
		this.socket = this.fsdb.onSnapshot( _doc => {
			if ( _doc.exists ) {
				this.doc = _doc;
				changeListener();
			} else {
				console.log( "Error Finding Document" );
			}
		});
	}

	// Close Database Connection
	closeDatabase() {
		this.socket();
	}

	// get image URL
	get imageURL() {
		return this.doc.get( KEY_IMAGE );
	}

	// get caption
	get caption() {
		return this.doc.get( KEY_CAPTION );
	}

	// get author
	get author() {
		return this.doc.get( KEY_AUTHOR );
	}
	get liked() {
		return this.doc.get( KEY_LIKED );
	}

	// update image
	update( caption ) {
		if ( this.author == iface.loginManager.uid ) {
			this.fsdb.update({
				[ KEY_CAPTION ]: caption,
				[ KEY_LAST_UPDATED ]: firebase.firestore.Timestamp.now(),
			}).then(() => {
				console.log( "doc updated" );
			});
		} else {
			console.log( "Permission Denieded" );
		}
	}

	// delete document
	delete() {
		if ( this.author == iface.loginManager.uid ) {
			return this.fsdb.delete();
		} else {
			console.log( "Permission Denieded" );
			return false;
		}
	}

	updateLikedStatus(imageId, isLiked) {
        if (this.author == iface.loginManager.uid || this.author != iface.loginManager.uid ) {
            this.fsdb.update({
                isLiked: isLiked,
            }).then(() => {
                console.log("Liked status updated");
            }).catch(error => {
                console.log(error);
            });
        } else {
            console.log("Permission Denied");
        }
    }

	

}


class DetailPageController {

	// Constucotr
	constructor() {

		let editImageBtn   = document.querySelector( "#submitEditImage" );
		let deleteImageBtn = document.querySelector( "#submitDeleteImage" );
		let likeImageBtn = document.querySelector("#likeImageBtn");

		
		iface.DetailPageManager.openDatabase( this.update );

		$( "#editImageDialog" ).on( "show.bs.modal", () => {
			this.update();
		});

		$( "#editImageDialog" ).on( "shown.bs.modal", () => {
			document.querySelector( "#inputCaption" ).focus();
		});

		likeImageBtn.addEventListener("click", () => {
			const image = iface.DetailPageManager.imageURL;
			const userId = iface.loginManager.uid;
		
			// Toggle the liked status in Firestore
			const isLiked = !image.isLiked;
			iface.DetailPageManager.updateLikedStatus(image.id, isLiked);
		
			// Update the button style based on the new liked status
			if (isLiked) {
				likeImageBtn.classList.add("liked");
			} else {
				likeImageBtn.classList.remove("liked");
			}
		});


		editImageBtn.addEventListener( "click", () => {
			iface.DetailPageManager.update(
					//document.querySelector( "#inputCaption" ).value
				);
		});

		deleteImageBtn.addEventListener( "click", () => {
			iface.DetailPageManager.delete().then( () => {
				window.location.href = `/list.html?uid=${ iface.loginManager.uid }`;
			});
		});
	}


	// update
	update() {
		let image     = iface.DetailPageManager.imageURL;
		let caption   = iface.DetailPageManager.caption;
		let notes   = iface.DetailPageManager.notes;
		let id        = iface.DetailPageManager.id;
		let author    = iface.DetailPageManager.author;
		let editFab   = document.querySelector( "#fab" );
		let dropdown  = document.querySelector( ".dropdown" );

		if ( iface.DetailPageManager.author == iface.loginManager.uid ) {
			editFab   .style.display = "block";
			dropdown  .style.display = "block";
		} else {
			editFab   .style.display = "none";
			dropdown  .style.display = "none";
		}
		


		//document.querySelector( "#inputCaption" ).value = caption;
		const list = document.querySelector( "#imageListContainer" );
		list.innerHTML = "";
		const newCard    = DetailPageController._createCard(
								new ImageItem( id, image, caption, author, notes ) );
		list.appendChild( newCard );
	}

	// create card
	static _createCard( image ) {
		return htmlToElement(
				`<div class="pin">
      <div class="video-embed">
        ${image.imageUrl}
      </div>
      <p class="caption bold" style = "font-weight: bold; font-size: 14px">${image.caption}</p>
	  <p class="notes">"3x12 Cable Y raises, 3x12 dumbbell shoulder press, 3x12 cable face pulls, 3x15 tricep rope pull down "</p>
	  
      ${
        image.author == iface.loginManager.uid
          ? `<p>Posted by ${image.author}</p>`
          : ''
      }
    </div>`
	)};
}

class AuthManager {

	// constructor
	constructor() {
		this.user = null;
	}

	// Start Listening
	beginListening( changeListener ) {
		firebase.auth().onAuthStateChanged( user => {
			this.user = user;
			changeListener();
		});
	}

	// Allow Signin
	signIn() {
		Rosefire.signIn( AUTH_TOKEN, ( err, rfUser ) => {
			if ( err ) {
				console.log( "Rosefire error", err );
				return;
			}

			firebase.auth().signInWithCustomToken( rfUser.token ).catch( err => {
				if ( err.code === 'auth/invalid-custom-token' ) {
					console.log( "Token Not Valid" );
				} else {
					console.log( "error", err.message );
				}
			});
		});
	}

	// Signout
	signOut() {
		firebase.auth().signOut();
	}

	// Get User ID
	get uid() {
		return this.user.uid;
	}

	// get display Name
	get displayName() {
		return this.user.displayName;
	}

	// Is Signed Out (Boolean)
	get isSignedIn() {
		return !!this.user;
	}

	// Do Login Redirect
	authRedirect() {
		let isLogin = !!document.querySelector( "[page='loginPage']" );
		if ( isLogin && this.isSignedIn ) window.location.href = "/list.html";
		if ( !isLogin && !this.isSignedIn ) window.location.href = "/";
	}
}


class LikedPageManager {
    constructor() {
        this.docs = [];
        this.socket = null;
		this.liked = liked;
        this.fsdb = firebase.firestore().collection(COLLECTION);
        this.uid = iface.loginManager.uid; // Liked images of the current user

		this.fsdb   = firebase.firestore().collection( COLLECTION );
		this.uid    = uid;
    }

    // Open Database Connection for Liked Images
    openDatabase(changeListener) {
        let query = this.fsdb.orderBy(KEY_LAST_UPDATED, "desc").limit(50);
        query = query.where(KEY_LIKED, "==", true);
        this.socket = query.onSnapshot((querySnapshot) => {
            this.docs = querySnapshot.docs;
            if (changeListener) changeListener();
        });
    }

    // Close Database Connection
    closeDatabase() {
        this.socket();
    }

    // ... (other methods as needed)
}

class ControllerLoginPage {
	constructor() {
		let button = document.querySelector( "#loginButton" );
		button.addEventListener( "click", () => {
			iface.loginManager.signIn();
		});

		var anonymousUser = firebase.auth().currentUser;
		let ui = new firebaseui.auth.AuthUI( firebase.auth() );
		ui.start( "#firebaseui-auth-container", {
			signInFlow: 'popup',
			signInOptions: [
				firebase.auth.EmailAuthProvider.PROVIDER_ID,
				firebase.auth.PhoneAuthProvider.PROVIDER_ID,
				firebase.auth.GoogleAuthProvider.PROVIDER_ID,
				firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID
			],
		});
	}
}

class LikedPageController {
    constructor() {
        iface.LikedPageManager.openDatabase(this.update);

        // Add any event listeners or UI interactions for the liked page
    }

    update() {
        const list = document.querySelector("#imageListContainer");
        list.innerHTML = "";

        for (let i = 0; i < iface.LikedPageManager.length; i++) {
			
            const image = iface.LikedPageManager.getImageByIndex(i);
			if(image.liked == true){
            const newCard = LikedPageController._createCard(image);
            newCard.addEventListener("click", () => {
                window.location.href = `/image.html?id=${image.id}`;
            });
            list.appendChild(newCard);
		}
        }
    }

    static _createCard(image) {
        return htmlToElement(
            `<div class="pin">
                <button class="btn btn-secondary" type="button" id="${image.id}-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <p class="caption">${image.caption}</p>
                    ${
                        image.author == iface.loginManager.uid
                        ? `<p>Posted by me</p>`
                        : ""
                    }
                </button>
            </div>`
        );
    }
}


class Page {
	static init() {
		let isList   = document.querySelector( "[page='listPage']"   );
		let isLiked  = document.querySelector( "[page='likedPage']");
		let isDetail = document.querySelector( "[page='detailPage']" );
		let isLogin  = document.querySelector( "[page='loginPage']"  );

		if ( isList ) {
			let urlParams = new URLSearchParams( window.location.search );
			let uid       = urlParams.get( "uid" );
			iface.ListPageManager    = new ListPageManager( uid );
			iface.ListPageController = new ListPageController();
		}

		if ( isDetail ) {
			let urlParams = new URLSearchParams( window.location.search );
			let id        = urlParams.get( "id" );
			iface.DetailPageManager    = new DetailPageManager( id );
			iface.DetailPageController = new DetailPageController();
		}
		
		if (isLiked) { // Initialize liked page
			let urlParams = new URLSearchParams( window.location.search );
			let likeImageBtn = document.querySelector("#likeImageBtn")
			console.log(likeImageBtn);
			let uid       = urlParams.get( "uid" );
            iface.LikedPageManager = new LikedPageManager( uid);
            iface.LikedPageController = new LikedPageController();

			likeImageBtn.addEventListener("click", () => {
				iface.DetailPageManager.toggleLikeImage(image.id); 
			});
			if(likeImageBtn.style.color == 'Black'){
				likeImageBtn.style.color = 'White';
				likeImageBack.style.backgroundColor = 'Lightgray';
			} else{
				likeImageBtn.style.color = 'Black';
				likeImageBack.style.backgroundColor = '#d9d9d9'
			}
        }

		if ( isDetail || isList ||isLiked ) {
			let btnLogout    = document.querySelector( "#menuLogout" );
			let btnAllImages = document.querySelector( "#menuAllImages" );
			let btnlikedImages = document.querySelector( "#menuLikedImages" );
			let btnMyImages  = document.querySelector( "#menuMyImages" );

			btnLogout.addEventListener( "click", event => {
				console.log( "Sign out" );
				iface.loginManager.signOut();
			});

			btnAllImages.addEventListener( "click", event => {
				window.location.href = "/list.html";
			});

			btnlikedImages.addEventListener( "click", event => {
				window.location.href = "/liked.html?";
			});

			btnMyImages.addEventListener( "click", event => {
				window.location.href = `/list.html?uid=${ iface.loginManager.uid}`;
			});
		}

		if ( isLogin ) {
			new ControllerLoginPage();
		}
	}
}



var iface = {};
iface.loginManager = new AuthManager();
iface.loginManager.beginListening( () => {
	console.log( `Login ${ iface.loginManager.isSignedIn } : ${ (iface.loginManager.isSignedIn) ? iface.loginManager.uid : "" }` );
	iface.loginManager.authRedirect();
	Page.init();
});